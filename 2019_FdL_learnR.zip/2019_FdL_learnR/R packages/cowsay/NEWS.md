cowsay 0.7
==========

### NEW FEATURES

* `cowsay` now supports colors via the `multicolor` package from [Amanda Dobbyn](https://github.com/aedobbyn). supports coloring by the thing being said (new `what_color` parameter) or the thing saying it (new `by_color` parameter). supports more than one color. thanks Amanda! (#59) (#61) 


cowsay 0.6
==========

### BUG FIXES

* Fix catfact API usage (#56) (#57)


cowsay 0.5
==========

### NEW FEATURES

* @ateucher added support for the `rmsfact` package, for 
random facts about Richard Stallman (#45)
* turkey animal added by @jeremycg , thanks Jeremy! (#46)
* @LucyMcGowan added a monkey, thanks Lucy! (#47)
* @GuangchuangYu added the BSD daemon, also called "beastie", 
thank so much! (#48) (#49)
* @onertipaday added support for quotes from the http://fillerama.io/
service with quotes from Futurama, Star Wars, Dexter, Monty Python, 
Doctor Who, and more. Thanks Paolo! (#51)

### MINOR IMPROVEMENTS

* removed broken link from readme and pkg (#43) 
thanks @apjanke

### BUG FIXES

* @ateucher fixed problem on windows (#40)
* @florianm fixed a spelling error (#41) (#42)


cowsay 0.4
==========

* First release to CRAN
