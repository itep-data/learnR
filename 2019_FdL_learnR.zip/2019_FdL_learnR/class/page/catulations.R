
# Graduation ceremony
library(cowsay)







say(what = "Cats have 32 muscles that control the outer ear (humans have only 6). A cat can independently rotate its ears 180 degrees. I am a snowman.", by = "snowman", type = "message", what_color = "orange")

say(what = "Congratulations Kayla! Awesome aeroBATics in this R class.", by = "bat", type = "message", what_color = "orange")


say(what = "Congratulations Kari! You are Eggcelent.", by = "chicken", type = "message", what_color = "orange")


say(what = "Congratulations Shane! Purrfect work.", by = "cat", type = "message", what_color = "orange")


say(what = "Congratulations Phil! You took a bite out of R.", by = "shark", type = "message", what_color = "orange")


say(what = "Congratulations Vallen! You've got to be kitten your R skills are too good.", by = "anxiouscat", type = "message", what_color = "orange")


say(what = "Congratulations Nick! You are owl in with R", by = "owl", type = "message", what_color = "orange")


say(what = "Congratulations Tyler! Mooooove over little data it's time for HUGE data.", by = "cow", type = "message", what_color = "orange")


say(what = "Congratulations Sarah! Leapin' lizards that was great work.", by = "frog", type = "message", what_color = "orange")


say(what = "Congratulations Brandy! Yoda woman!", by = "yoda", type = "message", what_color = "orange")


say(what = "Congratulations Nathan! fANTastic work!", by = "ant", type = "message", what_color = "orange")


say(what = "Congratulations Carma! Some bunny rocked this class.", by = "rabbit", type = "message", what_color = "orange")


say(what = "Congratulations Eric! You spun some genius in this class.", by = "spider", type = "message", what_color = "orange")

