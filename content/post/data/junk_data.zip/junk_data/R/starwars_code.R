# Get function help
help(sum)
?sum

# Create objects from thin air
droid <- "bb8"
droid

n_wookies <- 13
n_wookies*2

# For multiple items use c(1, 2, 3)
falcon <- c("Solo", "Chewie")
falcon

# Print an object's "structure"
str(falcon)

# Drop objects
rm(falcon)

# Use objects as variables for Math
n_wookies <- n_wookies + 1
n_wookies



# Below we create a dataframe that links starwars characters
# and their ages...and their dads?

starwars_names <- c("Luke", "Leia", "Han Solo")
starwars_names

starwars_ages <- c(19, 18, 25)
starwars_ages

# Starwars data frame ----
starwars_df <- data.frame(names = starwars_names,
                          ages = starwars_ages,
                          father = c("Darth","Darth", "Unknown"))
starwars_df


# Read in scrap data ----

library("readr")

scrap_file <- "data/starwars_scrap_jakku.csv"

scrap_data <- read_csv(scrap_file)


# ggplot -----
library(ggplot2)

head(scrap_data)

ggplot(data = scrap_data, aes(x = Origin, y = Amount)) +
  geom_col() +
  theme_bw()
