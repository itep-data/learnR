# R script

print("Hello World")
